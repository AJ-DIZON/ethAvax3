# README - ERC20 contract

This contract imported ERC20 so that the contract can transfer tokens from one account to another easily.

## Executing the program

First download project_2.sol. To run this program, you can use Remix, an online Solidity IDE. To get started, go to the Remix website at https://remix.ethereum.org/.

Next, upload the file you downloaded into the website and compile. Once compiled, you can deploy the contract